import { draw } from './plug_plot.js';

const engineEl = document.getElementById('engine');
const xiEl = document.getElementById('xi');
const dampEl = document.getElementById('damp');
const runBtn = document.getElementById('run');

// ---- Pure JS baseline (always available) ----
function wrapPi(x){ x=((x+Math.PI)%(2*Math.PI)); if(x<0)x+=2*Math.PI; return x-Math.PI; }

function runBaseline(xi, damping){
  const C=264.0, E=330.0, G=396.0;
  const dt=1e-4, T=0.5;
  const N=Math.ceil(T/dt);
  let pC=0.0, pE=0.5, pG=1.0;
  const xs=new Array(N), e54=new Array(N), e65=new Array(N), e32=new Array(N);
  for(let n=0;n<N;n++){
    xs[n]=n*dt;
    e54[n]=wrapPi(5*pC-4*pE);
    e65[n]=wrapPi(6*pE-5*pG);
    e32[n]=wrapPi(3*pC-2*pG);
    // baseline Euler step (triad with three couplings)
    let dC=2*Math.PI*dt*C - xi*Math.sin(5*pC-4*pE)*dt - xi*Math.sin(3*pC-2*pG)*dt - damping*pC*dt;
    let dE=2*Math.PI*dt*E + xi*Math.sin(5*pC-4*pE)*dt - xi*Math.sin(6*pE-5*pG)*dt - damping*pE*dt;
    let dG=2*Math.PI*dt*G + xi*Math.sin(6*pE-5*pG)*dt + xi*Math.sin(3*pC-2*pG)*dt - damping*pG*dt;
    pC+=dC; pE+=dE; pG+=dG;
  }
  draw(xs,e54,e65,e32);
}

// ---- Optional WASM upgrade (if present) ----
let wasmReady = false, ModuleRef=null;

async function tryLoadWasm(){
  try {
    const jsResp = await fetch('./rlang.js', {cache:'no-cache'});
    if(!jsResp.ok) return;
    const jsText = await jsResp.text();
    const blob = new Blob([jsText], {type:'text/javascript'});
    const url = URL.createObjectURL(blob);
    const mod = await import(url);
    URL.revokeObjectURL(url);

    if (typeof mod.default === 'function') {
      ModuleRef = await mod.default();
    } else if (typeof window.Module !== 'undefined') {
      ModuleRef = window.Module;
    } else if (typeof mod.Module !== 'undefined') {
      ModuleRef = mod.Module;
    }
    if (ModuleRef && typeof ModuleRef._rlang_new === 'function') {
      wasmReady = true;
      engineEl.textContent = 'RLang WASM';
    }
  } catch(e){
    // stay in baseline mode silently
  }
}

function runWasm(xi, damping){
  if(!wasmReady){ runBaseline(xi,damping); return; }
  ModuleRef._rlang_new();
  ModuleRef._rlang_set(xi, damping);
  ModuleRef._rlang_run(0.5, 1e-4);
  function grab(fn){
    const nPtr = ModuleRef._malloc(4);
    const p = ModuleRef[fn](nPtr);
    const n = ModuleRef.HEAP32[nPtr>>2];
    const out = Array.from(new Float64Array(ModuleRef.HEAPF64.buffer, p, n));
    ModuleRef._free(nPtr);
    return out;
  }
  const xs  = grab('_get_times');
  const e54 = grab('_get_err54');
  const e65 = grab('_get_err65');
  const e32 = grab('_get_err32');
  draw(xs,e54,e65,e32);
}

// UI
runBtn.onclick = ()=>{
  const xi=+xiEl.value, d=+dampEl.value;
  runWasm(xi,d);
};

// Try to upgrade to WASM on load (non-blocking)
tryLoadWasm();
