export function draw(xs, ys54, ys65, ys32) {
  const canvas = document.getElementById('plot');
  const ctx = canvas.getContext('2d');
  const w=canvas.width, h=canvas.height;
  const xmax = xs[xs.length-1] || 1;
  const ymin = -0.2, ymax = 0.2;

  ctx.clearRect(0,0,w,h);
  // tolerance lines
  ctx.strokeStyle="#2e3541";
  for (let y of [0.02,-0.02]){
    ctx.beginPath();
    const yy = h * (1 - (y - ymin)/(ymax - ymin));
    ctx.moveTo(0, yy); ctx.lineTo(w, yy); ctx.stroke();
  }
  // helper
  const line = (ys, color)=>{
    ctx.beginPath(); ctx.strokeStyle=color;
    for (let i=0;i<xs.length;i++){
      const x = (xs[i]/xmax)*w;
      const y = h * (1 - (ys[i]-ymin)/(ymax-ymin));
      if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    }
    ctx.stroke();
  };
  line(ys54, "#76c4ff");
  line(ys65, "#ffc76e");
  line(ys32, "#8bd37a");
}
