const canvas = document.getElementById('plot');
const ctx = canvas.getContext('2d');

function line(xs, ys) {
  const w=canvas.width, h=canvas.height;
  const xmax = xs[xs.length-1] || 1;
  const ymin = -0.2, ymax = 0.2;
  ctx.beginPath();
  for (let i=0;i<xs.length;i++){
    const x = (xs[i]/xmax)*w;
    const y = h - ((ys[i]-ymin)/(ymax-ymin))*h;
    if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
  }
  ctx.stroke();
}

export function draw(xs,e54,e65,e32){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.strokeStyle="#2e3541";
  for (let y of [0.02,-0.02]){
    ctx.beginPath();
    const yy = canvas.height * (0.5 - y/0.4);
    ctx.moveTo(0, yy); ctx.lineTo(canvas.width, yy); ctx.stroke();
  }
  ctx.strokeStyle="#76c4ff"; line(xs,e54);
  ctx.strokeStyle="#ffc76e"; line(xs,e65);
  ctx.strokeStyle="#8bd37a"; line(xs,e32);
}
