# RLang — Plug‑and‑Play Web Demo

This folder contains a **zero‑build** demo that works out‑of‑the‑box:
- It always runs using a small **pure JavaScript** integrator (baseline).
- If `rlang.js` + `rlang.wasm` are present next to `index.html`, it **automatically upgrades** to the high‑performance RLang WASM engine.

## How to use
1. Unzip these files into any folder.
2. Start a local server (don’t open with `file://`):
   ```bash
   python -m http.server -d . 8000
   ```
3. Open http://localhost:8000

You’ll see “Engine: JS Baseline”. If you later add the compiled WASM artifacts (`rlang.js`, `rlang.wasm`) into the same folder and refresh, it will show “Engine: RLang WASM” and use the native engine without changing the UI.
