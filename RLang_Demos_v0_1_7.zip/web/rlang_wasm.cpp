#include "rlang_fast_simd.hpp"
#include <vector>
#include <cmath>
#include <emscripten/emscripten.h>
static rlangf::System g_sys; static bool g_init=false; static int iC=-1,iE=-1,iG=-1;
static std::vector<double> g_t,g_e54,g_e65,g_e32;
extern "C" {
EMSCRIPTEN_KEEPALIVE void rlang_new(){ g_sys = rlangf::System(); iC=g_sys.add_osc(264.0,0.0,0.01,0.0,0.8); iE=g_sys.add_osc(330.0,0.5,0.01,0.0,0.7); iG=g_sys.add_osc(396.0,1.0,0.01,0.0,0.7);
  g_sys.couple_k(iC,iE,60.0,5,4); g_sys.couple_k(iE,iG,60.0,6,5); g_sys.couple_k(iC,iG,60.0,3,2); g_init=true; }
EMSCRIPTEN_KEEPALIVE void rlang_set(double xi,double damping){ if(!g_init) rlang_new(); for(size_t k=0;k<g_sys.couplings.size();++k) g_sys.couplings[k].strength=xi; for(size_t k=0;k<g_sys.osc.count;++k) g_sys.osc.damping[k]=damping; }
EMSCRIPTEN_KEEPALIVE void rlang_run(double T,double dt){ if(!g_init) rlang_new(); int N=(int)std::ceil(T/dt); g_t.assign(N,0); g_e54.assign(N,0); g_e65.assign(N,0); g_e32.assign(N,0);
  auto wrap=[](double x){ x=fmod(x+M_PI,2*M_PI); if(x<0)x+=2*M_PI; return x-M_PI; };
  for(int n=0;n<N;n++){ g_t[n]=n*dt; double pC=g_sys.osc.phase[iC], pE=g_sys.osc.phase[iE], pG=g_sys.osc.phase[iG]; g_e54[n]=wrap(5*pC-4*pE); g_e65[n]=wrap(6*pE-5*pG); g_e32[n]=wrap(3*pC-2*pG); g_sys.step_jobified(dt,0,true);} }
EMSCRIPTEN_KEEPALIVE const double* get_times(int* N){ *N=(int)g_t.size(); return g_t.data(); }
EMSCRIPTEN_KEEPALIVE const double* get_err54(int* N){ *N=(int)g_e54.size(); return g_e54.data(); }
EMSCRIPTEN_KEEPALIVE const double* get_err65(int* N){ *N=(int)g_e65.size(); return g_e65.data(); }
EMSCRIPTEN_KEEPALIVE const double* get_err32(int* N){ *N=(int)g_e32.size(); return g_e32.data(); }
}
