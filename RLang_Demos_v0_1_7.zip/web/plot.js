const canvas=document.getElementById('plot'); const ctx=canvas.getContext('2d');
function line(xs,ys){const w=canvas.width,h=canvas.height,xmax=xs[xs.length-1]||1,ymin=-0.2,ymax=0.2;ctx.beginPath();for(let i=0;i<xs.length;i++){const x=(xs[i]/xmax)*w;const y=h-((ys[i]-ymin)/(ymax-ymin))*h;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.stroke();}
function draw(xs,e54,e65,e32){ctx.clearRect(0,0,canvas.width,canvas.height);ctx.strokeStyle="#444";for(let y of [0.02,-0.02]){ctx.beginPath();const yy=canvas.height*(0.5 - y/0.4);ctx.moveTo(0,yy);ctx.lineTo(canvas.width,yy);ctx.stroke();}ctx.strokeStyle="#6cf";line(xs,e54);ctx.strokeStyle="#fc6";line(xs,e65);ctx.strokeStyle="#9f6";line(xs,e32);}
let ModuleReady=false; Module['onRuntimeInitialized']=()=>{ModuleReady=true;};
document.getElementById('run').onclick=()=>{ if(!ModuleReady){alert('WASM loading…');return;} const xi=+document.getElementById('xi').value; const damp=+document.getElementById('damp').value;
  Module._rlang_new(); Module._rlang_set(xi,damp); Module._rlang_run(0.5,1e-4);
  function grab(fn){ const nPtr=Module._malloc(4); const p=Module[fn](nPtr); const n=Module.HEAP32[nPtr>>2]; const out=Array.from(new Float64Array(Module.HEAPF64.buffer,p,n)); Module._free(nPtr); return out;}
  const xs=grab('_get_times'), e54=grab('_get_err54'), e65=grab('_get_err65'), e32=grab('_get_err32'); draw(xs,e54,e65,e32);
};
