# RLang Demos v0.1.7

Two minimal demos (drop-in) for your RLang repository — CLI comparison and a WASM web demo.

## 1) CLI comparison

Files:
- `demo/baseline_kuramoto.hpp`
- `demo/rlang_runner.hpp`
- `demo/compare_cli.cpp`

### CMake
```
add_executable(compare_cli demo/compare_cli.cpp)
target_include_directories(compare_cli PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/demo)
target_link_libraries(compare_cli PRIVATE rlang_fastdrop)
```

### Build & run
```
cmake -S . -B build -DRLANG_AVX2=ON
cmake --build build -j
./build/compare_cli
```
Outputs: console metrics + `triad_lock.wav`.

## 2) Web demo (WASM)

Files:
- `web/rlang_wasm.cpp`
- `web/index.html`
- `web/plot.js`

### CMake
```
if (EMSCRIPTEN)
  add_executable(rlang_wasm web/rlang_wasm.cpp)
  target_include_directories(rlang_wasm PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/web)
  target_link_libraries(rlang_wasm PRIVATE rlang_fastdrop)
  set_target_properties(rlang_wasm PROPERTIES
    LINK_FLAGS "-s EXPORTED_FUNCTIONS='[_rlang_new,_rlang_set,_rlang_run,_get_times,_get_err54,_get_err65,_get_err32]' -s EXPORTED_RUNTIME_METHODS='[cwrap,ccall,HEAP32,HEAPF64,_malloc,_free]' -s ALLOW_MEMORY_GROWTH=1 -s INVOKE_RUN=0 -s MODULARIZE=1 -s EXPORT_NAME=Module"
    OUTPUT_NAME "rlang")
endif()
```

### Build
```
emcmake cmake -S . -B build-wasm -DEMSCRIPTEN=ON
cmake --build build-wasm -j
# Copy build-wasm/rlang.js and rlang.wasm into /web and serve:
python -m http.server -d web 8000
```
Then open http://localhost:8000.

**Note:** Demos expect your FastDrop headers (e.g. `rlang_fast_simd.hpp`, `rlang_audio.hpp`) to be present in the repo.
