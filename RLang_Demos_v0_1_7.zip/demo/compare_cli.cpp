#include <cstdio>
#include <chrono>
#include "baseline_kuramoto.hpp"
#include "rlang_runner.hpp"
using clk = std::chrono::high_resolution_clock;
int main(){
    double C=264.0, E=330.0, G=396.0; double Xi=60.0, T=0.5, dt=1e-5, tol=0.02;
    baseline::System bsys; int bC=bsys.add_osc(C,0.0,0.01), bE=bsys.add_osc(E,0.5,0.01), bG=bsys.add_osc(G,1.0,0.01);
    bsys.couple_k(bC,bE,Xi,5,4); bsys.couple_k(bE,bG,Xi,6,5); bsys.couple_k(bC,bG,Xi,3,2);
    auto t0=clk::now(); auto bH=bsys.run(T,dt); double t_base=std::chrono::duration<double, std::milli>(clk::now()-t0).count();
    rlangdemo::Runner rr; int rC=rr.add(C,0.0,0.01,0.0,0.8), rE=rr.add(E,0.5,0.01,0.0,0.7), rG=rr.add(G,1.0,0.01,0.0,0.7);
    rr.couple(rC,rE,Xi,5,4); rr.couple(rE,rG,Xi,6,5); rr.couple(rC,rG,Xi,3,2);
    auto t1=clk::now(); auto rH=rr.run(T,dt); double t_rl=std::chrono::duration<double, std::milli>(clk::now()-t1).count();
    auto mb54=baseline::analyze(bH,5,4,bC,bE,tol); auto mb65=baseline::analyze(bH,6,5,bE,bG,tol); auto mb32=baseline::analyze(bH,3,2,bC,bG,tol);
    auto mr54=baseline::analyze(*(baseline::History*)&rH,5,4,rC,rE,tol); auto mr65=baseline::analyze(*(baseline::History*)&rH,6,5,rE,rG,tol); auto mr32=baseline::analyze(*(baseline::History*)&rH,3,2,rC,rG,tol);
    std::puts("\n== Phase-lock metrics (last 50% of samples) ==");
    std::printf("%-10s | %-10s | %-10s | %-12s | %-8s\n","engine","mean|err|","std","%locked<tol","time(ms)");
    std::printf("baseline   | %10.6f | %10.6f | %12.1f | %8.2f\n",(mb54.mean_abs_err+mb65.mean_abs_err+mb32.mean_abs_err)/3.0,(mb54.std_err+mb65.std_err+mb32.std_err)/3.0,(mb54.lock_pct+mb65.lock_pct+mb32.lock_pct)/3.0,t_base);
    std::printf("RLang      | %10.6f | %10.6f | %12.1f | %8.2f\n",(mr54.mean_abs_err+mr65.mean_abs_err+mr32.mean_abs_err)/3.0,(mr54.std_err+mr65.std_err+mr32.std_err)/3.0,(mr54.lock_pct+mr65.lock_pct+mr32.lock_pct)/3.0,t_rl);
    rlangdemo::Runner::to_wav(rH, {1,1,1}, "triad_lock.wav", 44100); std::puts("\nWrote: triad_lock.wav (mix of C,E,G)"); return 0;
}
