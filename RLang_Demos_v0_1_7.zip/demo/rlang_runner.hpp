#pragma once
#include <vector>
#include <cmath>
#include "rlang_fast_simd.hpp"
#include "rlang_audio.hpp"

namespace rlangdemo {

struct History { std::vector<double> t; std::vector<std::vector<double>> phases; };

struct Runner {
    rlangf::System sys;
    int add(double f,double phase=0,double damping=0.01,double ent=0.0,double amp=0.7){ return sys.add_osc(f,phase,damping,ent,amp); }
    void couple(int a,int b,double Xi,int p,int q){ sys.couple_k(a,b,Xi,p,q); }
    History run(double T,double dt){
        const int N=(int)std::ceil(T/dt); History H; H.t.resize(N);
        size_t M = sys.osc.count; H.phases.assign(M, std::vector<double>(N));
        for(int i=0;i<N;i++){ H.t[i]=i*dt; for(size_t k=0;k<M;k++) H.phases[k][i]=sys.osc.phase[k]; sys.step_jobified(dt, 0, true); }
        return H;
    }
    static void to_wav(const History& H, const std::vector<double>& amps, const char* path, int sr=44100){
        std::vector<float> mono; mono.reserve(H.t.size());
        for(size_t i=0;i<H.t.size();++i){ double s=0; for(size_t k=0;k<amps.size() && k<H.phases.size();++k) s += amps[k]*std::sin(H.phases[k][i]); mono.push_back((float)(s/std::max(1.0,(double)amps.size()))); }
        rlangf_audio::write_wav16(path, mono, sr);
    }
};

inline double wrap_pi(double x) { x = std::fmod(x + M_PI, 2.0*M_PI); if (x < 0) x += 2.0*M_PI; return x - M_PI; }

} // namespace rlangdemo
