#pragma once
#include <vector>
#include <cmath>
#include <cstdint>

namespace baseline {

inline double wrap_pi(double x) {
    x = std::fmod(x + M_PI, 2.0*M_PI);
    if (x < 0) x += 2.0*M_PI;
    return x - M_PI;
}

struct Osc { double freq_hz; double phase; double damping; };
struct Coupling { int a,b; int p,q; double Xi; };

struct History { std::vector<double> t; std::vector<std::vector<double>> phases; };

struct System {
    std::vector<Osc> osc; std::vector<Coupling> coup;
    int add_osc(double f, double phase=0.0, double damping=0.01){ osc.push_back({f,phase,damping}); return (int)osc.size()-1; }
    void couple_k(int a,int b,double Xi,int p,int q){ coup.push_back({a,b,p,q,Xi}); }
    History run(double T, double dt){
        const int N = (int)std::ceil(T/dt); History H; H.t.resize(N); H.phases.assign(osc.size(), std::vector<double>(N));
        for(int n=0;n<N;n++){ H.t[n]=n*dt;
            for(size_t i=0;i<osc.size();++i) H.phases[i][n]=osc[i].phase;
            std::vector<double> dphi(osc.size(), 2.0*M_PI*dt);
            for(size_t i=0;i<osc.size();++i) dphi[i]*=osc[i].freq_hz;
            for(const auto& c: coup){
                double e = c.p*osc[c.a].phase - c.q*osc[c.b].phase;
                double s = std::sin(e);
                dphi[c.a] += -c.Xi * s * dt - osc[c.a].damping * osc[c.a].phase * dt;
                dphi[c.b] +=  c.Xi * s * dt - osc[c.b].damping * osc[c.b].phase * dt;
            }
            for(size_t i=0;i<osc.size();++i) osc[i].phase += dphi[i];
        } return H;
    }
};

struct Metrics { double mean_abs_err=0, std_err=0, lock_pct=0, time_ms=0; };
inline Metrics analyze(const History& H, int p,int q,int a,int b, double tol, double tail_frac=0.5){
    Metrics m{}; int N = (int)H.t.size(); int i0 = (int)(N*(1.0-tail_frac));
    std::vector<double> e; e.reserve(N-i0);
    for(int i=i0;i<N;i++){ double ee = wrap_pi(p*H.phases[a][i] - q*H.phases[b][i]); e.push_back(ee); }
    double sum=0, sumabs=0; int locked=0;
    for(double v: e){ sum+=v; sumabs+=std::abs(v); if(std::abs(v)<tol) ++locked; }
    double mean = sum/e.size(); double var=0; for(double v: e){ double d=v-mean; var+=d*d; }
    m.mean_abs_err = sumabs/e.size(); m.std_err = std::sqrt(var/e.size()); m.lock_pct = 100.0*locked/e.size(); return m;
}

} // namespace baseline
